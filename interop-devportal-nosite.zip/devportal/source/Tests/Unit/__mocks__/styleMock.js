// For mor info refer : https://jestjs.io/docs/en/webpack
module.exports = {};
