import React from 'react';
import Typography from '@material-ui/core/Typography';
import Card from '@material-ui/core/Card';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import MaterialIcons from 'MaterialIcons';
import { app } from 'Settings';
import ImageGenerator from 'AppComponents/Apis/Listing/ImageGenerator';
import { ApiContext } from 'AppComponents/Apis/Details/ApiContext';
import classNames from 'classnames';

import CMServiceDelegate from 'AppData/custom/comi/CMServiceDelegate';

/**
 *
 *
 * @param {*} theme
 */
const styles = (theme) => ({
    card: {
        margin: theme.spacing(3 / 2),
        maxWidth: theme.custom.thumbnail.width,
        transition: 'box-shadow 0.3s ease-in-out',
        position: 'relative',
    },
    apiDetails: {
        padding: theme.spacing(1),
        background: theme.custom.thumbnail.contentBackgroundColor,
        color: theme.palette.getContrastText(theme.custom.thumbnail.contentBackgroundColor),
        '& a': {
            color: theme.palette.getContrastText(theme.custom.thumbnail.contentBackgroundColor),
        },
        position: theme.custom.thumbnail.contentPictureOverlap ? 'absolute' : 'relative',
        top: 0,
    },
    suppressLinkStyles: {
        textDecoration: 'none',
        color: theme.palette.text.disabled,
    },
    row: {
        display: 'inline-block',
    },
    thumbBy: {
        'padding-left': '5px',
    },
    media: {
        // ⚠️ object-fit is not supported by IE11.
        objectFit: 'cover',
    },
    thumbContent: {
        width: theme.custom.thumbnail.width - theme.spacing(2),
    },
    thumbLeft: {
        alignSelf: 'flex-start',
        flex: 1,
        width: '25%',
        'padding-left': '5px',
        'padding-right': '65px',
    },
    thumbLeftAction: {
        alignSelf: 'flex-start',
        flex: 1,
        width: '25%',
        'padding-left': '5px',
        'padding-right': '10px',
    },
    thumbRight: {
        display: 'flex',
        alignItems: 'flex-start',
        flexDirection: 'column',
    },
    thumbInfo: {
        display: 'flex',
    },
    thumbHeader: {
        width: theme.custom.thumbnail.width - theme.spacing(1),
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        cursor: 'pointer',
        margin: 0,
        'padding-left': '5px',
    },
    contextBox: {
        width: parseInt((theme.custom.thumbnail.width - theme.spacing(1)) / 2, 10),
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        cursor: 'pointer',
        margin: 0,
        display: 'inline-block',
        lineHeight: '1em',
        'padding-top': 5,
        'padding-right': 5,
        'padding-bottom': 1.5,
        textAlign: 'left',
    },
    context: {
        marginTop: 5,
    },
    thumbWrapper: {
        position: 'relative',
        paddingTop: 20,
        marginRight: theme.spacing(2),
    },
    deleteIcon: {
        fill: 'red',
    },
    textWrapper: {
        color: theme.palette.text.secondary,
        textDecoration: 'none',
    },
    imageWrapper: {
        color: theme.custom.thumbnail.iconColor,
        width: theme.custom.thumbnail.width,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageOverlap: {
        position: 'absolute',
        bottom: 1,
    },
    chipWrapper: {
        marginTop: '15px',
    },
    ratingWrapper: {
        marginTop: '20px',
    },
    textblock: {
        color: theme.palette.text.secondary,
        position: 'absolute',
        bottom: '35px',
        right: '10px',
        background: theme.custom.thumbnail.contentBackgroundColor,
        'padding-left': '10px',
        'padding-right': '10px',
    },
});

const windowURL = window.URL || window.webkitURL;

/**
 *
 * Render Category Card component in Category listing card view,containing essential
 * Category information like name , version ect
 * @class CategoryThumb
 * @extends {Component}
 */
class CategoryThumb extends React.Component {
    /**
     *Creates an instance of CategoryThumb.
     * @param {*} props
     * @memberof CategoryThumb
     */
    constructor(props) {
        super(props);
        this.state = {
            category: MaterialIcons.categories[0].name,
            selectedIcon: null,
            color: null,
            backgroundIndex: null,
            imageObj: null,
            isHover: false,
            imageLoaded: false,
        };
        this.toggleMouseOver = this.toggleMouseOver.bind(this);
    }

    /**
     *
     *
     * @memberof CategoryThumb
     */
    componentDidMount() {
        const { apiCategory } = this.props;
        const comiDelegate = new CMServiceDelegate();
        const promisedThumbnail = comiDelegate.getCategoryThumbnail(apiCategory.name);
        promisedThumbnail.then((response) => {
            if (response && response.url) {
                this.setState({ imageObj: response.url });
            }
        }).finally(() => {
            this.setState({ imageLoaded: true });
        });
    }

    /**
     * Clean up resource
     */
    componentWillUnmount() {
        if (this.state.thumbnail) {
            windowURL.revokeObjectURL(this.state.imageObj);
        }
    }

    /**
     * Get Path Prefix depedning on the respective Category Type being rendered
     *
     * @returns {String} path
     * @memberof CategoryThumb
     */
    getPathPrefix() {
        const path = '/apis/search';
        return path;
    }

    /**
     * Toggle mouse Hover state to set the card `raised` property
     *
     * @param {React.SyntheticEvent} event mouseover and mouseout
     * @memberof CategoryThumb
     */
    toggleMouseOver(event) {
        this.setState({ isHover: event.type === 'mouseover' });
    }

    /**
     * @inheritdoc
     * @returns {React.Component} @inheritdoc
     * @memberof CategoryThumb
     */
    render() {
        const {
            imageObj, selectedIcon, color, backgroundIndex, category, isHover, imageLoaded,
        } = this.state;
        const {
            apiCategory, classes, theme, customWidth, customHeight, showInfo,
        } = this.props;
        const { custom: { thumbnail } } = theme;
        const { name, description } = apiCategory;
        const path = this.getPathPrefix();

        const apisLink = path + '?offset=0&query=api-category%3A' + name;
        const imageWidth = customWidth || thumbnail.width;
        const imageHeight = customHeight || 140;
        const defaultImage = thumbnail.defaultApiImage;

        let ImageView;
        if (!imageLoaded) {
            ImageView = (
                <div className='image-load-frame'>
                    <div className='image-load-animation1' />
                    <div className='image-load-animation2' />
                </div>
            );
        } else if (imageObj) {
            ImageView = (
                <img
                    height={imageHeight}
                    width={imageWidth}
                    src={imageObj}
                    alt='Category Thumbnail'
                    className={classes.media}
                />
            );
        } else {
            ImageView = (
                <ImageGenerator
                    width={imageWidth}
                    height={imageHeight}
                    apiCategory={apiCategory}
                    fixedIcon={{
                        key: selectedIcon,
                        color: color || thumbnail.iconColor,
                        backgroundIndex,
                        category,
                    }}
                />
            );
        }
        return (
            <Card
                onMouseOver={this.toggleMouseOver}
                onFocus={this.toggleMouseOver}
                onMouseOut={this.toggleMouseOver}
                onBlur={this.toggleMouseOver}
                raised={isHover}
                className={classNames('image-thumbnail', classes.card)}
            >
                <CardMedia>
                    <Link to={apisLink} className={classes.suppressLinkStyles}>
                        {!defaultImage && ImageView}
                        {defaultImage && <img src={app.context + defaultImage} alt='img' />}
                    </Link>
                </CardMedia>
                {showInfo && (
                    <CardContent classes={{ root: classes.apiDetails }}>
                        <Link to={apisLink} className={classes.textWrapper}>
                            <Typography
                                className={classes.thumbHeader}
                                variant='h5'
                                component='h2'
                                gutterBottom
                                onClick={this.handleRedirectToAPIOverview}
                                title={name}
                            >
                                {name}
                            </Typography>
                        </Link>
                        <div className={classes.row}>
                            <Typography variant='caption' gutterBottom align='left' className={classes.thumbBy}>
                                {description}
                            </Typography>
                        </div>
                    </CardContent>
                )}
            </Card>
        );
    }
}
CategoryThumb.defaultProps = {
    customWidth: null,
    customHeight: null,
    showInfo: true,
};
CategoryThumb.propTypes = {
    classes: PropTypes.shape({}).isRequired,
    theme: PropTypes.shape({}).isRequired,
    customWidth: PropTypes.number,
    customHeight: PropTypes.number,
    showInfo: PropTypes.bool,
};

CategoryThumb.contextType = ApiContext;

export default withStyles(styles, { withTheme: true })(CategoryThumb);
