import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Icon from '@material-ui/core/Icon';
import { withStyles } from '@material-ui/core/styles';
import classNames from 'classnames';
import CustomIcon from 'AppComponents/Shared/CustomIcon';
import { ApiContext } from 'AppComponents/Apis/Details/ApiContext';
import { FormattedMessage } from 'react-intl';
import Settings from 'AppComponents/Shared/SettingsContext';

import CategoryTableView from 'AppComponents/custom/comi/Categories/Listing/CategoryTableView';

const styles = (theme) => ({
    rightIcon: {
        marginLeft: theme.spacing(1),
    },
    button: {
        margin: theme.spacing(1),
        marginBottom: 0,
    },
    buttonRight: {
        alignSelf: 'flex-end',
        display: 'flex',
    },
    ListingWrapper: {
        paddingTop: 10,
        paddingLeft: 35,
        maxWidth: theme.custom.contentAreaWidth,
    },
    appBar: {
        height: 70,
        background: theme.custom.infoBar.background,
        color: theme.palette.getContrastText(theme.custom.infoBar.background),
        borderBottom: 'solid 1px ' + theme.palette.grey.A200,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    mainIconWrapper: {
        paddingTop: 13,
        paddingLeft: 20,
        paddingRight: 20,
    },
    mainTitle: {
        paddingTop: 10,
    },
    mainTitleWrapper: {
        flexGrow: 1,
    },
    listContentWrapper: {
        padding: `0 ${theme.spacing(3)}px`,
        display: 'flex',
    },
    iconDefault: {
        color: theme.palette.getContrastText(theme.custom.infoBar.background),
    },
    iconSelected: {
        color: theme.custom.infoBar.listGridSelectedColor,
    },
    content: {
        flexGrow: 1,
        display: 'flex',
        flex: 1,
        flexDirection: 'column',
        paddingBottom: theme.spacing(3),
    },
    contentWithTags: {
        marginLeft: theme.custom.tagCloud.leftMenu.width,
    },
    contentWithoutTags: {
        marginLeft: -4,
    },
    contentWithTagsHidden: {
        marginLeft: theme.custom.tagCloud.leftMenu.sliderWidth,
    },
    LeftMenu: {
        backgroundColor: theme.custom.tagCloud.leftMenu.background,
        color: theme.custom.tagCloud.leftMenu.color,
        textAlign: 'left',
        fontFamily: theme.typography.fontFamily,
        position: 'absolute',
        bottom: 0,
        paddingLeft: 0,
        width: theme.custom.tagCloud.leftMenu.width,
        top: 0,
        left: 0,
        overflowY: 'auto',
    },
    LeftMenuForSlider: {
        backgroundColor: theme.custom.tagCloud.leftMenu.background,
        color: theme.custom.tagCloud.leftMenu.color,
        textAlign: 'left',
        fontFamily: theme.typography.fontFamily,
        position: 'absolute',
        bottom: 0,
        paddingLeft: 0,
        width: theme.custom.tagCloud.leftMenu.sliderWidth,
        top: 0,
        left: 0,
        overflowY: 'auto',
        display: 'flex',
    },
    sliderButton: {
        fontWeight: 200,
        background: theme.custom.tagCloud.leftMenu.sliderBackground,
        color: theme.palette.getContrastText(theme.custom.tagCloud.leftMenu.sliderBackground),
        height: theme.custom.infoBar.height,
        alignItems: 'center',
        display: 'flex',
        position: 'absolute',
        right: 0,
        cursor: 'pointer',
    },
    rotatedText: {
        transform: 'rotate(270deg)',
        transformOrigin: 'left bottom 0',
        position: 'absolute',
        whiteSpace: 'nowrap',
        top: theme.custom.infoBar.height * 4,
        marginLeft: 23,
        cursor: 'pointer',
    },
    recommendationsBar: {
        height: 60,
        background: theme.custom.infoBar.background,
        color: theme.palette.getContrastText(theme.custom.infoBar.background),
        borderBottom: 'solid 1px ' + theme.palette.grey.A200,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

const settings = Settings;

/**
 * Shared listing page
 *
 * @class CategoryListing
 * @extends {Component}
 */
class CategoryListing extends React.Component {
    /**
     * Constructor
     *
     * @param {*} props Properties
     */
    constructor(props) {
        super(props);
        let { defaultApiView } = props.theme.custom;
        this.showToggle = true;
        if (typeof defaultApiView === 'object' && defaultApiView.length > 0) {
            if (defaultApiView.length === 1) { // We will disable the other
                this.showToggle = false;
            }
            [defaultApiView] = defaultApiView;
        } else {
            defaultApiView = localStorage.getItem('portal.listType') || defaultApiView;
        }
        this.state = {
            listType: defaultApiView,
            showLeftMenu: false,
            isMonetizationEnabled: false,
        };
    }

    /**
     *
     * Get all tags
     * @memberof CategoryListing
     */
    componentDidMount() {
        this.isMonetizationEnabled();
    }

    /**
     *
     * Switch the view between grid and list view
     * @param {String} value view type
     * @memberof CategoryListing
     */
    setListType = (value) => {
        localStorage.setItem('portal.listType', value);
        this.setState({ listType: value });
    };

    toggleLeftMenu = () => {
        this.setState((prevState) => ({ showLeftMenu: !prevState.showLeftMenu }));
    };

    /**
     * retrieve Settings from the context and check the monetization enabled
     */
    isMonetizationEnabled = () => {
        // const settingsContext = this.context;
        const enabled = settings.monetizationEnabled;
        this.setState({ isMonetizationEnabled: enabled });
    }

    /**
     *
     * @inheritdoctheme
     * @returns {React.Component} @inheritdoc
     * @memberof CategoryListing
     */
    render() {
        const {
            theme,
            classes,
        } = this.props;
        const {
            listType,
            showLeftMenu,
            isMonetizationEnabled,
        } = this.state;
        const strokeColorMain = theme.palette.getContrastText(theme.custom.infoBar.background);
        const tagPaneVisible = false;
        const categoryPaneVisible = false;
        return (
            <>
                <main
                    className={classNames(
                        classes.content,
                        { [classes.contentWithoutTags]: !(tagPaneVisible || categoryPaneVisible) || !showLeftMenu },
                        { [classes.contentWithTagsHidden]: (tagPaneVisible || categoryPaneVisible) && !showLeftMenu },
                        { [classes.contentWithTags]: (tagPaneVisible || categoryPaneVisible) && showLeftMenu },
                    )}
                    id='categoryListing'
                >
                    <div className={classes.appBar} id='categoryListingAppBar'>
                        <div className={classes.mainIconWrapper}>
                            <CustomIcon strokeColor={strokeColorMain} width={42} height={42} icon='api' />
                        </div>
                        <div className={classes.mainTitleWrapper} id='mainTitleWrapper'>
                            <Typography variant='h4' component='h1' className={classes.mainTitle}>
                                <FormattedMessage
                                    defaultMessage='API Categories'
                                    id='Categories.Listing.Listing.apis.main'
                                />
                            </Typography>
                        </div>
                        {this.showToggle && (
                            <div className={classes.buttonRight} id='listGridWrapper'>
                                <IconButton
                                    aria-label='List View'
                                    className={classes.button}
                                    onClick={() => this.setListType('list')}
                                >
                                    <Icon
                                        className={classNames(
                                            { [classes.iconSelected]: listType === 'list' },
                                            { [classes.iconDefault]: listType === 'grid' },
                                        )}
                                    >
                                        list
                                    </Icon>
                                </IconButton>
                                <IconButton
                                    aria-label='Grid view'
                                    className={classes.button}
                                    onClick={() => this.setListType('grid')}
                                >
                                    <Icon
                                        className={classNames(
                                            { [classes.iconSelected]: listType === 'grid' },
                                            { [classes.iconDefault]: listType === 'list' },
                                        )}
                                    >
                                        grid_on
                                    </Icon>
                                </IconButton>
                            </div>
                        )}
                    </div>
                    <div className={classes.listContentWrapper}>
                        {listType === 'grid' && (
                            <ApiContext.Provider value={{ isMonetizationEnabled }}>
                                <CategoryTableView gridView />
                            </ApiContext.Provider>
                        )}
                        {listType === 'list' && (
                            <ApiContext.Provider value={{ isMonetizationEnabled }}>
                                <CategoryTableView gridView={false} />
                            </ApiContext.Provider>
                        )}
                    </div>
                </main>
            </>
        );
    }
}

CategoryListing.propTypes = {
    classes: PropTypes.shape({}).isRequired,
    theme: PropTypes.shape({}).isRequired,
    location: PropTypes.shape({
        search: PropTypes.string,
    }),
};

CategoryListing.defaultProps = {
    location: PropTypes.shape({
        search: '',
    }),
};

export default withStyles(styles, { withTheme: true })(CategoryListing);
