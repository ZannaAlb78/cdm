import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';

const customBackgroundColor = '#EFEFEF';
const customTextColor = '#2C4964';
const customButtonAreaBackgroundColor = 'white';
const customButtonBackgroundColor = '#444444';
const customButtonTextColor = 'white';
const customButtonLink = 'site/public/custom/comi/pdf/EA-ISTR-ManualeUtente-SIN00034-API_store_WSO2-1.0.pdf';

const useStyles = makeStyles(() => ({
    general: {
        backgroundColor: customBackgroundColor,
        color: customTextColor,
        height: '100%',
        width: '100%',
        fontFamily: 'sans-serif',
        fontSize: '50px',
        paddingTop: '5%',
        paddingBottom: '100%',
        paddingLeft: '10%',
        paddingRight: '10%',
        lineHeight: 3,
    },
    buttonArea: {
        backgroundColor: customButtonAreaBackgroundColor,
        color: customTextColor,
        height: 150,
        fontSize: '25px',
        paddingTop: '1%',
        paddingBottom: '1%',
        paddingLeft: '1%',
        paddingRight: '1%',
        lineHeight: 2,
    },
    button: {
        backgroundColor: customButtonBackgroundColor,
        color: customButtonTextColor,
        height: 50,
        fontSize: '15px',
    },

}));

/**
 * Default Manuale overview page
 *
 * @returns {React.Component}
 */
function Manuale() {
    const classes = useStyles();
    return (
        <main className={classes.general}>
            <div>Manuale</div>
            <div className={classes.buttonArea}>
                <div>Documentazione utilizzo API Comune di Milano</div>
                <div>
                    <Button
                        className={classes.button}
                        onClick={() => {
                            window.open(customButtonLink, 'EA-ISTR-ManualeUtente-SIN00034-API_store_WSO2-1.0.pdf');
                        }}
                    >
                        Download
                    </Button>
                </div>
            </div>
        </main>
    );
}

export default Manuale;
