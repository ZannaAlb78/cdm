import SelectInput from "@material-ui/core/Select/SelectInput";

function aggiustaSelectSearch() {
    // modifico il layout della combo facendolo simile a quello originale wso2
    // rimuovo div che contiene la freccia a destra di srotolamento tendina (non va bene come grafica)
    if (document.getElementsByClassName('css-1wy0on6')!==null && document.getElementsByClassName('css-1wy0on6')[0]!==null
        && document.getElementsByClassName('css-1wy0on6').length > 0){
        document.getElementsByClassName('css-1wy0on6')[0].remove();
    }

    // creo freccia srotolamento tendina con stesso stile wso2
    var divSelectSearch = document.getElementById('my_select_search'); //Get svg element
    if (divSelectSearch!==null){
        var svg = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
        svg.setAttribute("class","MuiSvgIcon-root MuiSelect-icon MuiSelect-iconOutlined");
        svg.setAttribute("focusable","false");
        svg.setAttribute("viewBox","0 0 24 24");
        svg.setAttribute("aria-hidden","true");
        svg.setAttribute("role","presentation");

        // immagine della freccia per abbassare la combo
        var path = document.createElementNS("http://www.w3.org/2000/svg", 'path'); //Create a path in SVG's namespace
        path.setAttribute("d","M7 10l5 5 5-5z"); //Set path's data

        svg.appendChild(path);
        divSelectSearch.appendChild(svg);

        // serve a creare lo sfondo bianco sulla scritta 'cmdb application2, avendo opacita' a 1
        var label = document.getElementById('outlined-select-currency-label-cmdbAppLabel');
        label.style.backgroundColor ="rgba(255, 255, 255, 1.0)";

        //var borderSelect = ReactDOM.findDOMNode(document.getElementsByClassName('css-1207jxz-control')[0].style.borderWidth= "1px");

        // id del div interessato cambia sempre, quindi ricerca per nodi e sotto nodi
        document.getElementById('my_select_search').getElementsByTagName("div")[0].getElementsByTagName("div")[0].id="my_select_search_border";
        //document.styleSheets[0].insertRule('#my_select_search_border:hover { border-color: rgb(0, 110, 156); }', 0);
        // su passaggio mouse, bordino 1px nero
        document.styleSheets[0].insertRule('#my_select_search_border:hover { border-color: rgb(0,0,0); }', 0);
        document.styleSheets[0].insertRule('#my_select_search_border:hover { border-width: 1px; }', 0);

        // IE, ma si spacca chrome, da capire
        //document.styleSheets[0].addRule('#my_select_search_border:hover { border-color: rgb(0,0,0); }', 0);
        //document.styleSheets[0].addRule('#my_select_search_border:hover { border-width: 1px; }', 0);

        // aggiusto zindex per tendina select in modo che vada sopra il campo "application description"
        document.getElementById('outlined-select-currency-label-cmdbAppLabel').style.zIndex=3;
        document.getElementById('my_select_search').getElementsByTagName("div")[0].style.zIndex=2;
        // colore del bordo quando si clicca sul div
        // rimane sempre bordino più spesso, colorato di verdino, si puo' tenere cosi' per dare enfasi al campo delle application cmdb
        document.getElementById('my_select_search').getElementsByTagName("div")[0].getElementsByTagName("div")[0].style.boxShadow="rgb(0, 110, 156) 0px 0px 0px 1px";
        // forzo colore rosso su asterisco della label cmdb application
        document.getElementById('cmdbApplicationAsterisk').style.color="red";
    }
}
