import React from 'react';
import { Link } from 'react-router-dom';
import { createMuiTheme, MuiThemeProvider, withStyles } from '@material-ui/core/styles';
import MUIDataTable from 'mui-datatables';
import merge from 'lodash.merge';
import cloneDeep from 'lodash.clonedeep';
import { withTheme } from '@material-ui/styles';
import Configurations from 'Config';
import withSettings from 'AppComponents/Shared/withSettingsContext';
import Loading from 'AppComponents/Base/Loading/Loading';
import Alert from 'AppComponents/Shared/Alert';
import CustomIcon from 'AppComponents/Shared/CustomIcon';
import ImageGenerator from 'AppComponents/Apis/Listing/ImageGenerator';
import { ApiContext } from 'AppComponents/Apis/Details/ApiContext';
import NoApi from 'AppComponents/Apis/Listing/NoApi';
import { injectIntl } from 'react-intl';
import API from 'AppData/api';
import AuthManager from 'AppData/AuthManager';

// import CMServiceDelegate from 'AppData/custom/comi/CMServiceDelegate';
import CategoryThumb from 'AppComponents/custom/comi/Categories/Listing/CategoryThumb';
import DefaultConfigurations from '../../../../../../defaultTheme';

const styles = (theme) => ({
    rowImageOverride: {
        '& .material-icons': {
            marginTop: 5,
            color: `${theme.custom.thumbnail.iconColor} !important`,
            fontSize: `${theme.custom.thumbnail.listViewIconSize}px !important`,
        },
    },
    apiNameLink: {
        display: 'flex',
        alignItems: 'center',
        '& span': {
            marginLeft: theme.spacing(1),
        },
        color: theme.palette.getContrastText(theme.custom.listView.tableBodyEvenBackgrund),
    },
});
/**
 * Table view for api listing
 *
 * @class CategoryTableView
 * @extends {React.Component}
 */
class CategoryTableView extends React.Component {
    /**
     * @inheritdoc
     * @param {*} props properties
     * @memberof CategoryTableView
     */
    constructor(props) {
        super(props);
        this.state = {
            data: null,
            loading: true,
        };
        this.page = 0;
        this.count = 100;
        this.rowsPerPage = localStorage.getItem('portal.numberOfRows') || 10;
        this.pageType = null;
    }

    componentDidMount() {
        this.apiType = this.context.apiType;
        this.getData();
    }

    componentDidUpdate(prevProps) {
        const { query, selectedTag } = this.props;
        if (
            this.apiType !== this.context.apiType
            || query !== prevProps.query
            || prevProps.selectedTag !== selectedTag
        ) {
            this.page = 0;
            this.apiType = this.context.apiType;
            this.getData();
        }
    }

    getMuiTheme = () => {
        const { gridView, theme } = this.props;
        let themeAdditions = {};
        const muiTheme = {
            overrides: {
                MUIDataTable: {
                    root: {
                        backgroundColor: 'transparent',
                        marginLeft: 40,
                        marginBottom: 20,
                        width: '100%',
                    },
                    paper: {
                        boxShadow: 'none',
                        backgroundColor: 'transparent',
                        width: '100%',
                    },
                    tableRoot: {
                        border: 'solid 1px #fff',
                        '& a': {
                            display: 'flex',
                            alignItems: 'center',
                        },
                        '& a > div': {
                            paddingRight: 10,
                        },
                        '& td': {
                            whiteSpace: 'nowrap',
                            lineHeight: 1,
                        },
                        '& tr:nth-child(even)': {
                            backgroundColor: theme.custom.listView.tableBodyEvenBackgrund,
                            '& td': {
                                color: theme.palette.getContrastText(theme.custom.listView.tableBodyEvenBackgrund),
                            },
                        },
                        '& tr:nth-child(odd)': {
                            backgroundColor: theme.custom.listView.tableBodyOddBackgrund,
                            '& td': {
                                color: theme.palette.getContrastText(theme.custom.listView.tableBodyOddBackgrund),
                            },
                        },
                        '& th': {
                            backgroundColor: theme.custom.listView.tableHeadBackground,
                            color: theme.palette.getContrastText(theme.custom.listView.tableHeadBackground),
                        },
                    },
                },
                MUIDataTablePagination: {
                    root: {
                        color: theme.palette.getContrastText(theme.palette.background.default),
                    },
                },
                MuiMenuItem: {
                    root: {
                        color: theme.palette.getContrastText(theme.palette.background.default),
                    },
                },
                MUIDataTableToolbar: {
                    root: {
                        '& svg': {
                            color: theme.palette.getContrastText(theme.palette.background.default),
                        },
                    },
                },
            },
        };
        if (gridView) {
            themeAdditions = {
                overrides: {
                    MUIDataTable: {
                        tableRoot: {
                            display: 'block',
                            border: 'none',
                            '& tbody': {
                                display: 'flex',
                                flexWrap: 'wrap',
                                marginLeft: 0,
                            },
                            '& thead': {
                                display: 'none',
                            },
                            '& tr:nth-child(odd),& tr:nth-child(even)': {
                                display: 'block',
                                marginRight: 5,
                                marginBottom: 5,
                                backgroundColor: 'transparent',
                            },
                            '& td': {
                                display: 'block',
                                backgroundColor: 'transparent',
                            },
                        },
                        paper: {
                            boxShadow: 'none',
                            backgroundColor: 'transparent',
                        },
                    },
                    MUIDataTableBodyCell: {
                        root: {
                            backgroundColor: 'transparent',
                            width: '100%',
                        },
                    },
                },
            };
        }
        const systemTheme = merge({}, DefaultConfigurations, Configurations, { custom: cloneDeep(theme.custom) });
        const dataTableTheme = merge({}, muiTheme, systemTheme, themeAdditions);
        return createMuiTheme(dataTableTheme);
    };

    removeCategoriaRiservatoIfnotAdmin = (list) => {
        // rimuovo la categoria 'Riservato' se non sono loggato perche'
        // tra le categorie di default non si deve vedere
        let result = [];
        this.user = AuthManager.getUser();
        if (!this.user || this.user == null || this.user.name !== 'admin') {
            let keyc = null;
            for (keyc of Object.keys(list)) {
                // console.log('keyc:' + list[keyc].name);
                // console.log('keyc Riservato:' + list[keyc].name.includes('Riservato'));
                // se non include 'Riservato' pusho l'oggetto categoria
                if (!list[keyc].name.includes('Riservato')) {
                    result.push(list[keyc]);
                }
            }
        } else {
            result = list;
        }
        return result;
    };

    // get data
    getData = () => {
        const { intl } = this.props;
        this.setState({ loading: true });
        this.xhrRequest()
            .then((data) => {
                const { body } = data;
                const { count } = body;
                this.count = count;
                this.list = this.removeCategoriaRiservatoIfnotAdmin(body.list);
                this.setState({ data: this.list });
            })
            .catch((error) => {
                const { response } = error;
                const { setTenantDomain } = this.props;
                if (response && response.body.code === 901300) {
                    setTenantDomain('INVALID');
                    Alert.error(intl.formatMessage({
                        defaultMessage: 'Invalid tenant domain',
                        id: 'Category.Listing.CategoryTableView.invalid.tenant.domain',
                    }));
                } else {
                    Alert.error(intl.formatMessage({
                        defaultMessage: 'Error While Loading Categories',
                        id: 'Category.Listing.CategoryTableView.error.loading',
                    }));
                }
            })
            .finally(() => {
                this.setState({ loading: false });
            });
    };

    xhrRequest = () => {
        // const { page, rowsPerPage } = this;
        // const comiDelegate = new CMServiceDelegate();
        // return comiDelegate.getCategories(page * rowsPerPage, this.rowsPerPage);
        const restApiClient = new API();
        return restApiClient.apiCategories();
    };

    changePage = (page) => {
        const { intl } = this.props;
        this.page = page;
        this.setState({ loading: true });
        this.xhrRequest()
            .then((data) => {
                const { body } = data;
                // const { list } = body;
                this.list = this.removeCategoriaRiservatoIfnotAdmin(body.list);
                this.setState({ data: this.list });
                // this.setState({
                //     data: list,
                // });
            })
            .catch(() => {
                Alert.error(intl.formatMessage({
                    defaultMessage: 'Error While Loading APIs',
                    id: 'Category.Listing.CategoryTableView.error.loading2',
                }));
            })
            .finally(() => {
                this.setState({ loading: false });
            });
    };

    /**
     * @inheritdoc
     * @returns {Component}x
     * @memberof CategoryTableView
     */
    render() {
        const { intl, gridView, theme } = this.props;
        const { loading } = this.state;
        const columns = [
            {
                name: 'id',
                options: {
                    display: 'excluded',
                    filter: false,
                },
            },
            {
                name: 'name',
                options: {
                    customBodyRender: (value, tableMeta, updateValue, tableViewObj = this) => {
                        if (tableMeta.rowData) {
                            const artifact = tableViewObj.state.data[tableMeta.rowIndex];
                            return <ImageGenerator api={artifact} width={30} height={30} />;
                        }
                        return <span />;
                    },
                    sort: false,
                    filter: false,
                    display: 'excluded',
                },
            },
            {
                name: 'name',
                label: intl.formatMessage({
                    id: 'Categories.Listing.CategoryTableView.name',
                    defaultMessage: 'Name',
                }),
                options: {
                    customBodyRender: (value, tableMeta, updateValue, tableViewObj = this) => {
                        if (tableMeta.rowData) {
                            const artifact = tableViewObj.state.data[tableMeta.rowIndex];
                            const categoryName = tableMeta.rowData[2];
                            const { classes } = this.props;
                            if (artifact) {
                                const strokeColor = theme.palette
                                    .getContrastText(theme.custom.listView.tableBodyEvenBackgrund);
                                return (
                                    <Link
                                        to={'/apis/search?offset=0&query=api-category%3A' + categoryName}
                                        className={classes.rowImageOverride}
                                    >
                                        <CustomIcon width={16} height={16} icon='api' strokeColor={strokeColor} />
                                        <span>{categoryName}</span>
                                    </Link>
                                );
                            }
                        }
                        return <span />;
                    },
                    sort: false,
                    filter: false,
                },
            },
        ];
        const { page, count, rowsPerPage } = this;
        const { data } = this.state;
        const options = {
            filterType: 'dropdown',
            responsive: 'stacked',
            serverSide: true,
            search: false,
            count,
            page,
            onTableChange: (action, tableState) => {
                switch (action) {
                    case 'changePage':
                        this.changePage(tableState.page);
                        break;
                    default:
                        break;
                }
            },
            selectableRows: 'none',
            rowsPerPage,
            onChangeRowsPerPage: (numberOfRows) => {
                if (page * numberOfRows > count) {
                    this.page = 0;
                }
                this.rowsPerPage = numberOfRows;
                localStorage.setItem('portal.numberOfRows', numberOfRows);
                this.getData();
            },
        };
        if (gridView) {
            options.customRowRender = (dataObj, dataIndex, rowIndex, tableViewObj = this) => {
                const artifact = tableViewObj.state.data[dataIndex];
                if (artifact) {
                    return (
                        <tr key={rowIndex}>
                            <td>
                                <CategoryThumb
                                    apiCategory={artifact}
                                    customHeight={theme.custom.thumbnail.height}
                                    customWidth={theme.custom.thumbnail.width}
                                />
                            </td>
                        </tr>
                    );
                }
                return <span />;
            };
            options.title = false;
            options.filter = false;
            options.print = false;
            options.download = false;
            options.viewColumns = false;
            options.customToolbar = false;
        } else {
            options.filter = false;
        }

        // disablito la paginazione
        options.pagination = false;

        if (loading) {
            return <Loading />;
        }
        if ((data && data.length === 0) || !data) {
            return <NoApi />;
        }
        return (
            <MuiThemeProvider theme={this.getMuiTheme()}>
                <MUIDataTable title='' data={data} columns={columns} options={options} />
            </MuiThemeProvider>
        );
    }
}

CategoryTableView.contextType = ApiContext;

export default withSettings(injectIntl(withTheme(withStyles(styles)(CategoryTableView))));
